# 🌃 Cyberpunk Portfolio

Um portfólio futurista com estética cyberpunk, repleto de efeitos neon, animações de glitch e interatividade avançada.

## ✨ Características

### Design Visual
- **Paleta de cores neon**: Rosa (#ff00ff), Ciano (#00ffff), Verde (#00ff00)
- **Efeitos de glitch**: Animações de distorção em textos e elementos
- **Elementos geométricos**: Padrões de circuito e formas futuristas
- **Overlays de ruído**: Visual retrô-futurista com scanlines
- **Brilho neon**: Sombras e efeitos de glow em elementos importantes

### Tipografia
- **Orbitron**: Fonte principal para títulos (futurista)
- **Rajdhani**: Fonte secundária para corpo de texto
- **Share Tech Mono**: Fonte monoespaçada para elementos tipo terminal
- **Efeitos de texto**: Animações de digitação e scramble

### Estrutura
- ✅ Seção Hero com texto neon animado
- ✅ Seção Sobre Mim com avatar cyberpunk
- ✅ Seção Portfolio com 6 projetos e filtros
- ✅ Seção Serviços com 4 cards futuristas
- ✅ Seção Contato com formulário estilizado
- ✅ Design 100% responsivo

### Elementos Interativos
- ✅ Navegação com efeitos de hover neon
- ✅ Cursor personalizado com rastro
- ✅ Filtros para projetos do portfólio
- ✅ Alternador de modo claro/escuro
- ✅ Formulário com validação e feedback visual
- ✅ Animações de transição suaves

### Gráficos SVG
- ✅ SVG de fundo para o hero com grid e circuitos
- ✅ Avatar de perfil com elementos cibernéticos
- ✅ 6 miniaturas de projetos com temas cyberpunk
- ✅ 4 ícones de serviço personalizados
- ✅ Elementos decorativos geométricos

### Funcionalidades JavaScript
- ✅ Sistema de partículas animadas no fundo
- ✅ Efeitos de texto com glitch e scramble
- ✅ Animações de scroll reveal
- ✅ Filtro interativo de projetos
- ✅ Validação de formulário completa
- ✅ Cursor personalizado com física
- ✅ Contador animado de estatísticas
- ✅ Efeito parallax
- ✅ Easter egg (Konami Code)

## 🚀 Como Usar

### Instalação Local

1. **Extrair o arquivo ZIP**
   ```bash
   unzip cyberpunk-portfolio.zip
   cd cyberpunk-portfolio
   ```

2. **Abrir no navegador**
   - Simplesmente abra o arquivo `index.html` em seu navegador
   - Ou use um servidor local:
   ```bash
   # Python 3
   python3 -m http.server 8000
   
   # Node.js (http-server)
   npx http-server
   ```

3. **Acessar**
   - Abra `http://localhost:8000` no navegador

### Hospedagem

#### GitHub Pages
1. Crie um repositório no GitHub
2. Faça upload de todos os arquivos
3. Vá em Settings > Pages
4. Selecione a branch main e salve

#### Netlify
1. Arraste a pasta do projeto para [netlify.com/drop](https://app.netlify.com/drop)
2. Pronto! Seu site está online

#### Vercel
```bash
npm i -g vercel
vercel
```

## 📁 Estrutura de Arquivos

```
cyberpunk-portfolio/
├── index.html              # Página principal
├── css/
│   └── styles.css         # Estilos completos
├── js/
│   ├── particles.js       # Sistema de partículas
│   ├── cursor.js          # Cursor personalizado
│   ├── glitch.js          # Efeitos de glitch
│   ├── navigation.js      # Navegação e menu
│   ├── animations.js      # Animações de scroll
│   ├── portfolio.js       # Filtro de projetos
│   ├── form.js            # Validação de formulário
│   └── main.js            # Arquivo principal
├── images/
│   ├── hero-bg.svg        # Fundo do hero
│   ├── avatar.svg         # Avatar cyberpunk
│   ├── project1-6.svg     # Projetos
│   └── service-*.svg      # Ícones de serviços
└── README.md              # Este arquivo
```

## 🎨 Personalização

### Cores
Edite as variáveis CSS em `css/styles.css`:
```css
:root {
  --neon-pink: #ff00ff;
  --neon-cyan: #00ffff;
  --neon-green: #00ff00;
  --bg-dark: #0a0a0a;
}
```

### Conteúdo
- **Textos**: Edite diretamente no `index.html`
- **Projetos**: Adicione mais `.portfolio-item` na seção de portfolio
- **Serviços**: Adicione mais `.service-card` na seção de serviços

### Animações
Ajuste velocidades em `js/animations.js`:
```javascript
const duration = 2000; // milissegundos
const delay = 0.1;     // segundos
```

## 🎮 Easter Eggs

### Konami Code
Digite a sequência: ↑ ↑ ↓ ↓ ← → ← → B A

Ativa o **Matrix Mode** com chuva de caracteres verdes!

### Debug Mode
Adicione `#debug` na URL para ativar o modo de debug:
```
http://localhost:8000/#debug
```

## 🌐 Compatibilidade

### Navegadores Suportados
- ✅ Chrome 90+
- ✅ Firefox 88+
- ✅ Safari 14+
- ✅ Edge 90+

### Dispositivos
- ✅ Desktop (1920x1080 e superiores)
- ✅ Laptop (1366x768 e superiores)
- ✅ Tablet (768x1024)
- ✅ Mobile (375x667 e superiores)

## ⚡ Performance

### Otimizações Implementadas
- Lazy loading de imagens
- Uso de `requestAnimationFrame` para animações
- Intersection Observer para scroll animations
- SVGs otimizados
- CSS com seletores eficientes
- JavaScript modular

### Métricas Esperadas
- **First Contentful Paint**: < 1.5s
- **Time to Interactive**: < 3.5s
- **Lighthouse Score**: 90+

## 🛠️ Tecnologias

- **HTML5**: Estrutura semântica
- **CSS3**: Animações, Grid, Flexbox
- **JavaScript ES6+**: Classes, Modules, Async/Await
- **SVG**: Gráficos vetoriais escaláveis
- **Google Fonts**: Orbitron, Rajdhani, Share Tech Mono

## 📝 Licença

Este projeto é de código aberto e está disponível para uso pessoal e comercial.

## 🤝 Contribuições

Sinta-se à vontade para:
- Reportar bugs
- Sugerir melhorias
- Adicionar novos recursos
- Compartilhar seu portfólio customizado

## 📧 Contato

Para dúvidas ou sugestões:
- Email: dev@cyberpunk.com
- GitHub: [@cyberpunk-dev](https://github.com)

---

**Desenvolvido com 💜 e muito ☕ em 2025**

*"O futuro é agora, e é neon!"* 🌆✨
